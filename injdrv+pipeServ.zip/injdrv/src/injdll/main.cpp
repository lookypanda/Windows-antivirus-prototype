#define _ARM_WINAPI_PARTITION_DESKTOP_SDK_AVAILABLE 1

#include "wow64log.h"
#include <Windows.h>
#include <Psapi.h>

//#include <stdio.h>
//#include <string.h>
//#include <string.h>
//#include <stdio.h>
//#include <ntddk.h>
//
// Include NTDLL-related headers.
//
#define NTDLL_NO_INLINE_INIT_STRING
#include <ntdll.h>
#include <fstream>
#if defined(_M_IX86)
#  define ARCH_A          "x86"
#  define ARCH_W         L"x86"
#elif defined(_M_AMD64)
#  define ARCH_A          "x64"
#  define ARCH_W         L"x64"
#elif defined(_M_ARM)
#  define ARCH_A          "ARM32"
#  define ARCH_W         L"ARM32"
#elif defined(_M_ARM64)
#  define ARCH_A          "ARM64"
#  define ARCH_W         L"ARM64"
#else
#  error Unknown architecture
#endif


// size_t strlen(const char * str)
// {
//   const char *s;
//   for (s = str; *s; ++s) {}
//   return(s - str);
// }

//
// Include support for ETW logging.
// Note that following functions are mocked, because they're
// located in advapi32.dll.  Fortunatelly, advapi32.dll simply
// redirects calls to these functions to the ntdll.dll.
//

#define EventActivityIdControl  EtwEventActivityIdControl
#define EventEnabled            EtwEventEnabled
#define EventProviderEnabled    EtwEventProviderEnabled
#define EventRegister           EtwEventRegister
#define EventSetInformation     EtwEventSetInformation
#define EventUnregister         EtwEventUnregister
#define EventWrite              EtwEventWrite
#define EventWriteEndScenario   EtwEventWriteEndScenario
#define EventWriteEx            EtwEventWriteEx
#define EventWriteStartScenario EtwEventWriteStartScenario
#define EventWriteString        EtwEventWriteString
#define EventWriteTransfer      EtwEventWriteTransfer

#include <evntprov.h>

//
// Include Detours.
//

#include <detours.h>

//
// This is necessary for x86 builds because of SEH,
// which is used by Detours.  Look at loadcfg.c file
// in Visual Studio's CRT source codes for the original
// implementation.
//

#if defined(_M_IX86) || defined(_X86_)

EXTERN_C PVOID __safe_se_handler_table[]; /* base of safe handler entry table */
EXTERN_C BYTE  __safe_se_handler_count;   /* absolute symbol whose address is
                                             the count of table entries */
EXTERN_C
CONST
DECLSPEC_SELECTANY
IMAGE_LOAD_CONFIG_DIRECTORY
_load_config_used = {
    sizeof(_load_config_used),
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    (SIZE_T)__safe_se_handler_table,
    (SIZE_T)&__safe_se_handler_count,
};

#endif

//
// Unfortunatelly sprintf-like functions are not exposed
// by ntdll.lib, which we're linking against.  We have to
// load them dynamically.
//

using _snwprintf_fn_t = int (__cdecl*)(
  wchar_t *buffer,
  size_t count,
  const wchar_t *format,
  ...
  );

using _dll_funct_test_fn_t = int(__cdecl*)(
 int num
  );

inline _snwprintf_fn_t my_snwprintf = nullptr;
inline _dll_funct_test_fn_t _dll_test = nullptr;

//
// ETW provider GUID and global provider handle.
//

//
// GUID:
//   {a4b4ba50-a667-43f5-919b-1e52a6d69bd5}
//

GUID ProviderGuid = {
  0xa4b4ba50, 0xa667, 0x43f5, { 0x91, 0x9b, 0x1e, 0x52, 0xa6, 0xd6, 0x9b, 0xd5 }
};

REGHANDLE ProviderHandle;

int json_log(const char* functname, PWCHAR databuffer)
{
  WCHAR OutBuffer[256] = { 0 };
  my_snwprintf(OutBuffer,
    RTL_NUMBER_OF(OutBuffer),
    L"{ \"FUNCT\":\"%hs\", \"PARAM\":\"%ws\" }",
    functname,
    databuffer);


  EtwEventWriteString(ProviderHandle, 0, 0, OutBuffer);
  return 0;
}

//
// Hooking functions and prototypes.
//

//inline decltype(WriteProcessMemory)* Real_WriteProcessMemory = nullptr;
//
//BOOL __stdcall Mine_WriteProcessMemory(HANDLE a0,
//  LPVOID lpBase,
//  LPVOID lpBuf,
//  DWORD_PTR nSize,
//  PDWORD_PTR a4)
//{
//
//  WCHAR Buffer[128];
//  _snwprintf(Buffer,
//    RTL_NUMBER_OF(Buffer),
//    L"WriteProcessMemory(%p,@%p..%p,%p,%p)\n",
//    a0, lpBase,
//    (PBYTE)lpBase + ((nSize > 0) ? nSize - 1 : 0),
//    lpBuf, a4);
//
//  
//
//  BOOL rv = 0;
//  __try {
//    rv = Real_WriteProcessMemory(a0, lpBase, lpBuf, nSize, a4);
//  }
//  __finally {
//    _snwprintf(Buffer,
//      RTL_NUMBER_OF(Buffer),
//      L"WriteProcessMemory(,,,,) -> %p\n", rv);
//
//  };
//  EtwEventWriteString(ProviderHandle, 0, 0, Buffer);
//  return rv;
//}
//
//inline decltype(CreateThread)* Real_CreateThread = nullptr;
//EXTERN_C HANDLE NTAPI Mine_CreateThread(LPSECURITY_ATTRIBUTES a0,
//  ULONG_PTR a1,
//  LPTHREAD_START_ROUTINE a2,
//  LPVOID a3,
//  DWORD a4,
//  LPDWORD a5)
//{
//  WCHAR Buffer[128];
//  _snwprintf(Buffer,
//    RTL_NUMBER_OF(Buffer),
//    L"CreateThread(%p,%p,%p,%p,%p,%p)\n", a0, a1, a2, a3, a4, a5);
//
//  HANDLE rv = 0;
//  __try {
//    rv = Real_CreateThread(a0, a1, a2, a3, a4, a5);
//  }
//  __finally {
//    _snwprintf(Buffer,
//      RTL_NUMBER_OF(Buffer),
//      L"CreateThread(,,,,,) -> %p\n", rv);
//  };
//  EtwEventWriteString(ProviderHandle, 0, 0, Buffer);
//  return rv;
//}




//typedef enum HardErrorResponseType {
//  ResponseTypeAbortRetryIgnore,
//  ResponseTypeOK,
//  ResponseTypeOKCancel,
//  ResponseTypeRetryCancel,
//  ResponseTypeYesNo,
//  ResponseTypeYesNoCancel,
//  ResponseTypeShutdownSystem,
//  ResponseTypeTrayNotify,
//  ResponseTypeCancelTryAgainContinue
//} HardErrorResponseType;
//
//typedef enum HardErrorResponse {
//  ResponseReturnToCaller,
//  ResponseNotHandled,
//  ResponseAbort, ResponseCancel,
//  ResponseIgnore,
//  ResponseNo,
//  ResponseOk,
//  ResponseRetry,
//  ResponseYes
//} HardErrorResponse;
//
typedef enum HardErrorResponseButton {
  ResponseButtonOK,
  ResponseButtonOKCancel,
  ResponseButtonAbortRetryIgnore,
  ResponseButtonYesNoCancel,
  ResponseButtonYesNo,
  ResponseButtonRetryCancel,
  ResponseButtonCancelTryAgainContinue
} HardErrorResponseButton;

typedef enum HardErrorResponseDefaultButton {
  DefaultButton1 = 0,
  DefaultButton2 = 0x100,
  DefaultButton3 = 0x200
} HardErrorResponseDefaultButton;

typedef enum HardErrorResponseIcon {
  IconAsterisk = 0x40,
  IconError = 0x10,
  IconExclamation = 0x30,
  IconHand = 0x10,
  IconInformation = 0x40,
  IconNone = 0,
  IconQuestion = 0x20,
  IconStop = 0x10,
  IconWarning = 0x30,
  IconUserIcon = 0x80
} HardErrorResponseIcon;

typedef enum HardErrorResponseOptions {
  ResponseOptionNone = 0,
  ResponseOptionDefaultDesktopOnly = 0x20000,
  ResponseOptionHelp = 0x4000,
  ResponseOptionRightAlign = 0x80000,
  ResponseOptionRightToLeftReading = 0x100000,
  ResponseOptionTopMost = 0x40000,
  ResponseOptionServiceNotification = 0x00200000,
  ResponseOptionServiceNotificationNT3X = 0x00040000,
  ResponseOptionSetForeground = 0x10000,
  ResponseOptionSystemModal = 0x1000,
  ResponseOptionTaskModal = 0x2000,
  ResponseOptionNoFocus = 0x00008000
} HardErrorResponseOptions;

bool G_sys_proc = false;

bool Mine_WinExec_load = false;
bool Mine_WinExec_inj = false;
bool Mine_ShellExecute_load = false;



int my_MsgBox(const wchar_t *  msg) {
  //const char* p;
  //p =strstr("this is a test", "NO");
  //if (p == NULL)
  //{
  //  WCHAR Buffer[128];
  //  _snwprintf(Buffer,
  //    RTL_NUMBER_OF(Buffer),
  //    L"SRTSRT NUUUUL");
  //  EtwEventWriteString(ProviderHandle, 0, 0, Buffer);
  //  return 1;
  //}
  if (G_sys_proc)
  {
    return 1;
  }


  UNICODE_STRING Title;
  ULONG Response;

  //RtlInitUnicodeString(&Title, (PWSTR)L"Message from kernel mode");

  ////ULONG_PTR p[] = { (ULONG_PTR)pRegistryPath,(ULONG_PTR)& Title,0x40 | 2 }; // MB_ICONINFORMATION|MB_ABORTRETRYIGNORE
      // To display a custom string:
  UNICODE_STRING wTitle, wText;
  RtlInitUnicodeString(&wTitle, (PWSTR)L"Dinamic check");
  RtlInitUnicodeString(&wText, (PWSTR)msg);
  ULONG_PTR params[4] = {
      (ULONG_PTR)& wText,
      (ULONG_PTR)& wTitle,
      (
          (ULONG)ResponseButtonOKCancel |
          (ULONG)IconExclamation |
          (ULONG)ResponseOptionNone |
          (ULONG)DefaultButton1
      ),
      INFINITE
  };


  NtRaiseHardError(STATUS_SERVICE_NOTIFICATION, 4, 0x3, params, OptionOkCancel, &Response);

  WCHAR Buffer[128];
  switch (Response)
  {
  case ResponseOk:

    my_snwprintf(Buffer,
      RTL_NUMBER_OF(Buffer),
      L"ResponseOk button clicked");
    //EtwEventWriteString(ProviderHandle, 0, 0, Buffer);
    json_log("MsgBox_INFO", Buffer);
    return 1;
    break;
  case ResponseCancel:
    my_snwprintf(Buffer,
      RTL_NUMBER_OF(Buffer),
      L"ResponseCancel button clicked");
    json_log("MsgBox_INFO", Buffer);
    //EtwEventWriteString(ProviderHandle, 0, 0, Buffer);
    return 0;
    break;
  case ResponseIgnore:
    my_snwprintf(Buffer,
      RTL_NUMBER_OF(Buffer),
      L"Ignore button clicked");
    json_log("MsgBox_INFO", Buffer);
    //EtwEventWriteString(ProviderHandle, 0, 0, Buffer);
    break;
  default:
    break;
  }
  return 0;
}



inline decltype(NtCreateProcess)* Real_NtCreateProcess = nullptr;

NTSTATUS
NTAPI
Mine_NtCreateProcess(
  _Out_ PHANDLE ProcessHandle,
  _In_ ACCESS_MASK DesiredAccess,
  _In_opt_ POBJECT_ATTRIBUTES ObjectAttributes,
  _In_ HANDLE ParentProcess,
  _In_ BOOLEAN InheritObjectTable,
  _In_opt_ HANDLE SectionHandle,
  _In_opt_ HANDLE DebugPort,
  _In_opt_ HANDLE ExceptionPort
) {
  
  WCHAR OutBuffer[128];
  my_snwprintf(OutBuffer,
    RTL_NUMBER_OF(OutBuffer),
    L"(ProcessHandle %hs, DesiredAccess %hs, ParentProcess %hs)",
    ProcessHandle,
    DesiredAccess,
    ParentProcess);

  json_log("NtCreateProcess", OutBuffer);
  if (Mine_WinExec_load && Mine_ShellExecute_load)
  {
    int ret = my_MsgBox(L"Process runing NtCreateProcess after WinExec &  SHELL32.dll");
    if (!ret) {
      ExitProcess(1);
      return NULL;
    }
  }
  else
    if (Mine_WinExec_load)
    {
      int ret = my_MsgBox(L"Process runing NtCreateProcess after WinExec");
      if (!ret) {
        ExitProcess(1);
        return NULL;
      }
    }
    else
      if (Mine_ShellExecute_load) {
        int ret = my_MsgBox(L"Process runing NtCreateProcess after SHELL32.dll");
        if (!ret) {
          ExitProcess(1);
          return NULL;
        }
      }
  //EtwEventWriteString(ProviderHandle, 0, 0, OutBuffer);

  //
  // Call original function.
  //

  return Real_NtCreateProcess(ProcessHandle,
    DesiredAccess,
    ObjectAttributes,
    ParentProcess,
    InheritObjectTable,
    SectionHandle,
    DebugPort,
    ExceptionPort);
}





inline decltype(NtCreateProcessEx)* Real_NtCreateProcessEx = nullptr;


NTSTATUS
NTAPI
Mine_NtCreateProcessEx(
  _Out_ PHANDLE ProcessHandle,
  _In_ ACCESS_MASK DesiredAccess,
  _In_opt_ POBJECT_ATTRIBUTES ObjectAttributes,
  _In_ HANDLE ParentProcess,
  _In_ ULONG Flags,
  _In_opt_ HANDLE SectionHandle,
  _In_opt_ HANDLE DebugPort,
  _In_opt_ HANDLE ExceptionPort,
  _In_ ULONG JobMemberLevel
) {
  WCHAR OutBuffer[128];
  my_snwprintf(OutBuffer,
    RTL_NUMBER_OF(OutBuffer),
    L"(ProcessHandle %hs, DesiredAccess %hs, ParentProcess %hs, Flags %hs )",
    ProcessHandle,
    DesiredAccess,
    ParentProcess,
    Flags);

  json_log("NtCreateProcessEX", OutBuffer);
  if (Mine_WinExec_load && Mine_ShellExecute_load)
  {
    int ret = my_MsgBox(L"Process runing NtCreateProcessEX after WinExec &  SHELL32.dll");
    if (!ret) {
      ExitProcess(1);
      return NULL;
    }
  }
  else
    if (Mine_WinExec_load)
    {
      int ret = my_MsgBox(L"Process runing NtCreateProcessEX after WinExec");
      if (!ret) {
        ExitProcess(1);
        return NULL;
      }
    }
    else
      if (Mine_ShellExecute_load) {
        int ret = my_MsgBox(L"Process runing NtCreateProcessEX after SHELL32.dll");
        if (!ret) {
          ExitProcess(1);
          return NULL;
        }
      }
  //EtwEventWriteString(ProviderHandle, 0, 0, OutBuffer);
  //
  // Call original function.
  //

  return Real_NtCreateProcessEx(ProcessHandle, DesiredAccess, ObjectAttributes, ParentProcess, Flags, SectionHandle, DebugPort, ExceptionPort, JobMemberLevel);

}


inline decltype(NtCreateUserProcess)* Real_NtCreateUserProcess = nullptr;
NTSTATUS
NTAPI
Mine_NtCreateUserProcess(
  _Out_ PHANDLE ProcessHandle,
  _Out_ PHANDLE ThreadHandle,
  _In_ ACCESS_MASK ProcessDesiredAccess,
  _In_ ACCESS_MASK ThreadDesiredAccess,
  _In_opt_ POBJECT_ATTRIBUTES ProcessObjectAttributes,
  _In_opt_ POBJECT_ATTRIBUTES ThreadObjectAttributes,
  _In_ ULONG ProcessFlags, // PROCESS_CREATE_FLAGS_*
  _In_ ULONG ThreadFlags, // THREAD_CREATE_FLAGS_*
  _In_opt_ PRTL_USER_PROCESS_PARAMETERS ProcessParameters, // PRTL_USER_PROCESS_PARAMETERS
  _Inout_ PPS_CREATE_INFO CreateInfo,
  _In_opt_ PPS_ATTRIBUTE_LIST AttributeList
) {

  //
  // Call original function.
  //
  auto temp = Real_NtCreateUserProcess(
    ProcessHandle,
    ThreadHandle,
    ProcessDesiredAccess,
    ThreadDesiredAccess,
    ProcessObjectAttributes,
    ThreadObjectAttributes,
    ProcessFlags, // PROCESS_CREATE_FLAGS_*
    ThreadFlags, // THREAD_CREATE_FLAGS_*
    ProcessParameters, // PRTL_USER_PROCESS_PARAMETERS
    CreateInfo,
    AttributeList);

  WCHAR OutBuffer[128];
  my_snwprintf(OutBuffer,
    RTL_NUMBER_OF(OutBuffer),
    L"(ProcessHandle %p, ThreadHandle %p, ProcessFlags %d, ThreadFlags %d)",
    *ProcessHandle,
    *ThreadHandle,
    ProcessFlags,
    ThreadFlags);
  json_log("NtCreateUserProcess", OutBuffer);

  //EtwEventWriteString(ProviderHandle, 0, 0, OutBuffer);

  WCHAR OutBuffer2[128];
  my_snwprintf(OutBuffer2,
    RTL_NUMBER_OF(OutBuffer2),
    L"(ImagePathName %ws,  CommandLine: %ws)",
    (PRTL_USER_PROCESS_PARAMETERS)(ProcessParameters)->ImagePathName.Buffer,
    (PRTL_USER_PROCESS_PARAMETERS)(ProcessParameters)->CommandLine.Buffer);

  json_log("NtCreateUserProcessARGS", OutBuffer2);
  if (Mine_WinExec_load&& Mine_ShellExecute_load)
  {
    int ret = my_MsgBox(L"Process runing NtCreateUserProcess after WinExec &  SHELL32.dll");
    if (!ret) {
      ExitProcess(1);
      return NULL;
    }
  }
  else
    if (Mine_WinExec_load)
    {
      int ret = my_MsgBox(L"Process runing NtCreateUserProcess after WinExec");
      if (!ret) {
        ExitProcess(1);
        return NULL;
      }
    }
    else
      if (Mine_ShellExecute_load) {
        int ret = my_MsgBox(L"Process runing NtCreateUserProcess after SHELL32.dll");
        if (!ret) {
          ExitProcess(1);
          return NULL;
        }
      }

  //EtwEventWriteString(ProviderHandle, 0, 0, OutBuffer2);

  return temp;
}


inline decltype(NtWriteVirtualMemory)* Real_NtWriteVirtualMemory = nullptr;

NTSTATUS
NTAPI
Mine_NtWriteVirtualMemory(
  _In_ HANDLE ProcessHandle,
  _In_opt_ PVOID BaseAddress,
  _In_reads_bytes_(BufferSize) PVOID Buffer,
  _In_ SIZE_T BufferSize,
  _Out_opt_ PSIZE_T NumberOfBytesWritten
)
{


  WCHAR path[MAX_PATH];

 // GetModuleFileNameEx(ProcessHandle, 0,path, MAX_PATH);

  WCHAR OutBuffer[128];
  my_snwprintf(OutBuffer,
    RTL_NUMBER_OF(OutBuffer),
    L"(ProcessHandle %p,  BaseAddress%p, %p, BufferSize %i)",
    ProcessHandle,
    BaseAddress,
    (PBYTE)BaseAddress + ((BufferSize > 0) ? BufferSize - 1 : 0),
    BufferSize
  );
  json_log("NtWriteVirtualMemory", OutBuffer);
  if (Mine_WinExec_load && Mine_ShellExecute_load)
  {
    int ret = my_MsgBox(L"Process runing NtWriteVirtualMemory after WinExec &  SHELL32.dll");
    if (!ret) {
      ExitProcess(1);
      return NULL;
    }
  }
  else
    if (Mine_WinExec_load)
    {
      int ret = my_MsgBox(L"Process runing NtWriteVirtualMemory after WinExec");
      if (!ret) {
        ExitProcess(1);
        return NULL;
      }
    }
    else
      if (Mine_ShellExecute_load) {
        int ret = my_MsgBox(L"Process runing NtWriteVirtualMemory after SHELL32.dll");
        if (!ret) {
          ExitProcess(1);
          return NULL;
        }
      }

  //EtwEventWriteString(ProviderHandle, 0, 0, OutBuffer);


  //
  // Call original function.
  //

  return Real_NtWriteVirtualMemory(ProcessHandle,
    BaseAddress,
    Buffer,
    BufferSize,
    NumberOfBytesWritten);
}


inline decltype(NtReadVirtualMemory)*Real_NtReadVirtualMemory = nullptr;

NTSTATUS
NTAPI
Mine_NtReadVirtualMemory(
  _In_ HANDLE ProcessHandle,
  _In_opt_ PVOID BaseAddress,
  _Out_writes_bytes_(BufferSize) PVOID Buffer,
  _In_ SIZE_T BufferSize,
  _Out_opt_ PSIZE_T NumberOfBytesRead
)
{
  WCHAR OutBuffer[128];
  my_snwprintf(OutBuffer,
    RTL_NUMBER_OF(OutBuffer),
    L"(%p, %p, %i)",
    ProcessHandle,
    BaseAddress,
    (PBYTE)BaseAddress + ((BufferSize > 0) ? BufferSize - 1 : 0));
  json_log("NtReadVirtualMemory", OutBuffer);
  //EtwEventWriteString(ProviderHandle, 0, 0, OutBuffer);

  if (Mine_WinExec_load && Mine_ShellExecute_load)
  {
    int ret = my_MsgBox(L"Process runing NtReadVirtualMemory after WinExec &  SHELL32.dll");
    if (!ret) {
      ExitProcess(1);
      return NULL;
    }
  }
  else
    if (Mine_WinExec_load)
    {
      int ret = my_MsgBox(L"Process runing NtReadVirtualMemory after WinExec");
      if (!ret) {
        ExitProcess(1);
        return NULL;
      }
    }
    else
      if (Mine_ShellExecute_load) {
        int ret = my_MsgBox(L"Process runing NtReadVirtualMemory after SHELL32.dll");
        if (!ret) {
          ExitProcess(1);
          return NULL;
        }
      }

//
// Call original function.
//

  return Real_NtReadVirtualMemory(ProcessHandle,
    BaseAddress,
    Buffer,
    BufferSize,
    NumberOfBytesRead);
}

//////
inline decltype(NtQuerySystemInformation)* OrigNtQuerySystemInformation = nullptr;

EXTERN_C
NTSTATUS
NTAPI
HookNtQuerySystemInformation(
  _In_ SYSTEM_INFORMATION_CLASS SystemInformationClass,
  _Out_writes_bytes_opt_(SystemInformationLength) PVOID SystemInformation,
  _In_ ULONG SystemInformationLength,
  _Out_opt_ PULONG ReturnLength
  )
{
  //
  // Log the function call.
  //

  WCHAR Buffer[128];
  my_snwprintf(Buffer,
             RTL_NUMBER_OF(Buffer),
             L"(%i, %p, %i)",
             SystemInformationClass,
             SystemInformation,
             SystemInformationLength);
  json_log("NtQuerySystemInformation", Buffer);
  //EtwEventWriteString(ProviderHandle, 0, 0, Buffer);

  //
  // Call original function.
  //

  return OrigNtQuerySystemInformation(SystemInformationClass,
                                      SystemInformation,
                                      SystemInformationLength,
                                      ReturnLength);
}

inline decltype(NtCreateThread)* Real_NtCreateThread = nullptr;

NTSTATUS
NTAPI
Mine_NtCreateThread(
  _Out_ PHANDLE ThreadHandle,
  _In_ ACCESS_MASK DesiredAccess,
  _In_opt_ POBJECT_ATTRIBUTES ObjectAttributes,
  _In_ HANDLE ProcessHandle,
  _Out_ PCLIENT_ID ClientId,
  _In_ PCONTEXT ThreadContext,
  _In_ PINITIAL_TEB InitialTeb,
  _In_ BOOLEAN CreateSuspended
) {
  //
  // Log the function call.
  //

  WCHAR Buffer[128];
  my_snwprintf(Buffer,
    RTL_NUMBER_OF(Buffer),
    L"(ProcessHandle %p, ClientId %p)",
    ProcessHandle,
    ClientId);
  json_log("NtCreateThread", Buffer);
  //EtwEventWriteString(ProviderHandle, 0, 0, Buffer);

  //
  // Call original function.
  //

  return Real_NtCreateThread(ThreadHandle,
    DesiredAccess,
    ObjectAttributes,
    ProcessHandle,
    ClientId,
    ThreadContext,
    InitialTeb,
    CreateSuspended);

}

inline decltype(NtCreateThreadEx)* OrigNtCreateThreadEx = nullptr;

NTSTATUS
NTAPI
HookNtCreateThreadEx(
  _Out_ PHANDLE ThreadHandle,
  _In_ ACCESS_MASK DesiredAccess,
  _In_opt_ POBJECT_ATTRIBUTES ObjectAttributes,
  _In_ HANDLE ProcessHandle,
  _In_ PVOID StartRoutine, // PUSER_THREAD_START_ROUTINE
  _In_opt_ PVOID Argument,
  _In_ ULONG CreateFlags, // THREAD_CREATE_FLAGS_*
  _In_ SIZE_T ZeroBits,
  _In_ SIZE_T StackSize,
  _In_ SIZE_T MaximumStackSize,
  _In_opt_ PPS_ATTRIBUTE_LIST AttributeList
  )
{
  //
  // Log the function call.
  //

  WCHAR Buffer[128];
  my_snwprintf(Buffer,
             RTL_NUMBER_OF(Buffer),
             L"(ProcessHandle %p, StartRoutine %p, Argument %p)",
             ProcessHandle,
             StartRoutine, Argument);
  json_log("NtCreateThreadEx", Buffer);
  //EtwEventWriteString(ProviderHandle, 0, 0, Buffer);

  //
  // Call original function.
  //

  return OrigNtCreateThreadEx(ThreadHandle,
                              DesiredAccess,
                              ObjectAttributes,
                              ProcessHandle,
                              StartRoutine,
                              Argument,
                              CreateFlags,
                              ZeroBits,
                              StackSize,
                              MaximumStackSize,
                              AttributeList);
}

/*
using  WinExec_fn=UINT(__cdecl*)(
  LPCSTR lpCmdLine,
  UINT   uCmdShow
);
inline WinExec_fn WinExec2 = nullptr;

UINT WinExec(
  LPCSTR lpCmdLine,
  UINT   uCmdShow
);
inline decltype(WinExec)* Real_WinExec = nullptr;

UINT Mine_WinExec(
  LPCSTR lpCmdLine,
  UINT   uCmdShow
) {

  return Real_WinExec(lpCmdLine, uCmdShow);
}
*/



UINT(__stdcall* Real_WinExec)(LPCSTR lpCmdLine,
  UINT uCmdShow)
  = NULL;

//UINT(WINAPI * Real_WinExec)(LPCSTR lpCmdLine,
//  UINT   uCmdShow) = NULL;

UINT __stdcall Mine_WinExec(LPCSTR lpCmdLine,
  UINT   uCmdShow)
{
  WCHAR Buffer[128];
  my_snwprintf(Buffer,
    RTL_NUMBER_OF(Buffer),
    L"(lpCmdLine %hs, uCmdShow %d)",
    lpCmdLine,
    uCmdShow);
  json_log("WinExec", Buffer);
//EtwEventWriteString(ProviderHandle, 0, 0, Buffer);
  Mine_WinExec_load = true;
  int ret=my_MsgBox(L"Process runing WinExec");
  if (ret) {
      return Real_WinExec(lpCmdLine, uCmdShow); }
  else {

    ExitProcess(1);
    return NULL;
  }

}


inline decltype(LdrLoadDll)* Real_LdrLoadDll = nullptr;

NTSTATUS
NTAPI
Mine_LdrLoadDll(
  _In_opt_ PWSTR DllPath,
  _In_opt_ PULONG DllCharacteristics,
  _In_ PUNICODE_STRING DllName,
  _Out_ PVOID* DllHandle
) {



  NTSTATUS outTemp = Real_LdrLoadDll(DllPath, DllCharacteristics, DllName, DllHandle);

  WCHAR Buffer[128];
  my_snwprintf(Buffer,
    RTL_NUMBER_OF(Buffer),
    L"(DllName %s, DllHandle %p)",
    DllName->Buffer,
    *DllHandle);
  json_log("LdrLoadDll", Buffer);
  //EtwEventWriteString(ProviderHandle, 0, 0, Buffer);

UNICODE_STRING Kernel32_string;
  RtlInitUnicodeString(&Kernel32_string, (PWSTR)L"kernel32");
  
  if (RtlEqualUnicodeString(DllName,&Kernel32_string,TRUE)&& Mine_WinExec_inj ==false) {

    WCHAR Buffer[128];
    my_snwprintf(Buffer,
      RTL_NUMBER_OF(Buffer),
      L"TRY to HOOK WinExec ");
    json_log("INFO", Buffer);
    //EtwEventWriteString(ProviderHandle, 0, 0, Buffer);

    UNICODE_STRING KerneldllPath; 
    RtlInitUnicodeString(&KerneldllPath, (PWSTR)L"kernel32.dll");

    HANDLE KerneldllHandle;
    LdrGetDllHandle(NULL, 0, &KerneldllPath, &KerneldllHandle);

    ANSI_STRING RoutineName;
    RtlInitAnsiString(&RoutineName, (PSTR)"WinExec");
    //LdrGetProcedureAddress(KerneldllHandle, &RoutineName, 0, (PVOID*)& Real_WinExec);
    LdrGetProcedureAddress(*DllHandle, &RoutineName, 0, (PVOID*)& Real_WinExec);

    DetourTransactionBegin();
    DetourAttach((PVOID*)& Real_WinExec, Mine_WinExec);
    DetourTransactionCommit();

    Mine_WinExec_inj= true;
  }


  


  UNICODE_STRING SHELL32_string;
  RtlInitUnicodeString(&SHELL32_string, (PWSTR)L"SHELL32.dll");
  if (RtlEqualUnicodeString(DllName, &SHELL32_string, TRUE) && Mine_ShellExecute_load == false) {
    WCHAR Buffer[128];
    my_snwprintf(Buffer,
      RTL_NUMBER_OF(Buffer),
      L"TRY to HOOK SHELL32.dll ");
    json_log("INFO", Buffer);
    //EtwEventWriteString(ProviderHandle, 0, 0, Buffer);
    int ret = my_MsgBox(L"SHELL32.dll loaded!");
    if (!ret){
      ExitProcess(1);
      return NULL;
    }
    //ANSI_STRING RoutineName;
    //RtlInitAnsiString(&RoutineName, (PSTR)"WinExec");
    ////LdrGetProcedureAddress(KerneldllHandle, &RoutineName, 0, (PVOID*)& Real_WinExec);
    //LdrGetProcedureAddress(*DllHandle, &RoutineName, 0, (PVOID*)& Real_WinExec);

    //DetourTransactionBegin();
    //DetourAttach((PVOID*)& Real_WinExec, Mine_WinExec);
    //DetourTransactionCommit();

    //Mine_ShellExecute_load = true;
    Mine_ShellExecute_load = true;
  }
  return outTemp;
}






extern "C" NTSTATUS NTAPI ExRaiseHardError(
  NTSTATUS ErrorStatus,
  ULONG NumberOfParameters,
  ULONG UnicodeStringParameterMask,
  PULONG_PTR Parameters,
  ULONG ValidResponseOptions,
  PULONG Response
);




NTSTATUS
NTAPI
ThreadRoutine(
  _In_ PVOID ThreadParameter
  )
{
  LARGE_INTEGER Delay;
  Delay.QuadPart = -10 * 1000 * 100; // 100ms

  for (;;)
  {
    // EtwEventWriteString(ProviderHandle, 0, 0, L"NtDelayExecution(100ms)");

    NtDelayExecution(FALSE, &Delay);
  }
}


NTSTATUS
NTAPI
EnableDetours(
  VOID
  )
{
  DetourTransactionBegin();
  {
    OrigNtQuerySystemInformation = NtQuerySystemInformation;
    //DetourAttach((PVOID*)&OrigNtQuerySystemInformation, HookNtQuerySystemInformation);

    //Real_WriteProcessMemory = WriteProcessMemory;
    //DetourAttach((PVOID*)& Real_WriteProcessMemory, Mine_WriteProcessMemory);


    OrigNtCreateThreadEx = NtCreateThreadEx;
    DetourAttach((PVOID*)&OrigNtCreateThreadEx, HookNtCreateThreadEx);

    Real_NtCreateThread = NtCreateThread;
    DetourAttach((PVOID*)& Real_NtCreateThread, Mine_NtCreateThread);

    Real_NtReadVirtualMemory = NtReadVirtualMemory;
    DetourAttach((PVOID*)& Real_NtReadVirtualMemory, Mine_NtReadVirtualMemory);

    Real_NtWriteVirtualMemory = NtWriteVirtualMemory;
    DetourAttach((PVOID*)& Real_NtWriteVirtualMemory, Mine_NtWriteVirtualMemory);

    Real_NtCreateProcess = NtCreateProcess;
    DetourAttach((PVOID*)& Real_NtCreateProcess, Mine_NtCreateProcess);

    Real_NtCreateProcessEx = NtCreateProcessEx;
    DetourAttach((PVOID*)& Real_NtCreateProcessEx, Mine_NtCreateProcessEx);

    Real_NtCreateUserProcess = NtCreateUserProcess;
    DetourAttach((PVOID*)& Real_NtCreateUserProcess, Mine_NtCreateUserProcess);

    Real_LdrLoadDll = LdrLoadDll;
    DetourAttach((PVOID*)& Real_LdrLoadDll, Mine_LdrLoadDll);

    HINSTANCE hinstLib;

    // Load DLL file
    //my_MsgBox();
    //hinstLib = LoadLibrary(TEXT("kernel32.dll"));
    //if (hinstLib == NULL) {
    //  my_MsgBox();
    //}
    //my_MsgBox();
    //Real_WinExec = WinExec;
    //DetourAttach(&(PVOID&)Real_WinExec, Mine_WinExec);

    //Real_CreateThread = CreateThread;
    //DetourAttach((PVOID*)&Real_CreateThread, Mine_CreateThread);
  }
  DetourTransactionCommit();


  return STATUS_SUCCESS;
}

NTSTATUS
NTAPI
DisableDetours(
  VOID
  )
{
  DetourTransactionBegin();
  {
    //DetourDetach((PVOID*)&OrigNtQuerySystemInformation, HookNtQuerySystemInformation);

    //DetourDetach((PVOID*)& Real_WriteProcessMemory, Mine_WriteProcessMemory);

    DetourDetach((PVOID*)&OrigNtCreateThreadEx, HookNtCreateThreadEx);

    DetourDetach((PVOID*)& Real_NtCreateThread, Mine_NtCreateThread);

    DetourDetach((PVOID*)& Real_NtReadVirtualMemory, Mine_NtReadVirtualMemory);

    DetourDetach((PVOID*)& Real_NtWriteVirtualMemory, Mine_NtWriteVirtualMemory);

    DetourDetach((PVOID*)& Real_NtCreateProcess, Mine_NtCreateProcess);

    DetourDetach((PVOID*)& Real_NtCreateProcessEx, Mine_NtCreateProcessEx);

    DetourDetach((PVOID*)& Real_NtCreateUserProcess, Mine_NtCreateUserProcess);

    DetourDetach((PVOID*)& Real_LdrLoadDll, Mine_LdrLoadDll);
    //DetourDetach((PVOID*)&Real_CreateThread, Mine_CreateThread);
    //DetourDetach(&(PVOID&)Real_WinExec, Mine_WinExec);
    if (Mine_WinExec_inj == true)
    {
     DetourDetach((PVOID*)& Real_WinExec, Mine_WinExec);
    }
  }
  DetourTransactionCommit();

  return STATUS_SUCCESS;
}

int LoadFunction(const char * FName, const wchar_t * DllName, PVOID* func )//(PSTR)"_snwprintf" (PWSTR)L"ntdll.dll"
{
  //
// First, resolve address of the _snwprintf function.
//

  ANSI_STRING RoutineName;
  RtlInitAnsiString(&RoutineName, (PSTR)FName);

  UNICODE_STRING NtdllPath;
  RtlInitUnicodeString(&NtdllPath, (PWSTR)DllName);

  HANDLE NtdllHandle;
  LdrGetDllHandle(NULL, 0, &NtdllPath, &NtdllHandle);
  LdrGetProcedureAddress(NtdllHandle, &RoutineName, 0, (PVOID*)& func);
  return 1;
}
NTSTATUS
NTAPI
OnProcessAttach(
  _In_ PVOID ModuleHandle
  )
{


  //ANSI_STRING RoutineName;
  //RtlInitAnsiString(&RoutineName, (PSTR)"mytest");

  //UNICODE_STRING NtdllPath;
  //RtlInitUnicodeString(&NtdllPath, (PWSTR)L"C:\\1\\hello-world.dll");

  //HANDLE NtdllHandle;
  //LdrGetDllHandle(NULL, 0, &NtdllPath, &NtdllHandle);
  //LdrGetProcedureAddress(NtdllHandle, &RoutineName, 0, (PVOID*)& _dll_test);

  //
  // First, resolve address of the _snwprintf function.
  //
  //HINSTANCE hModule = NULL;
  //typedef  BOOL(WINAPI MESS)(UINT);
  //MESS* me = NULL;
  //hModule = LoadLibrary((PWSTR)"C:\\1\\hello-world-x86.dll");
  //if (hModule != NULL)
  //{
  //  //me = (MESS*)::GetProcAddress((HMODULE)hModule, "MessageBeep");
  //  //if (me != NULL)
  //  //{
  //  //	UINT type = 1;
  //  //	BOOL result;
  //  //	result = (*me)(type);
  //  //}
  //  //else cout << "Error Load function" << endl;
  //  ////::FreeLibrary(hModule);
  //}

  //int res=LoadFunction("_snwprintf",L"ntdll.dll", (PVOID*)_snwprintf);
  //DbgPrint((PSTR)"222222222222222222222222222222222222");
  ANSI_STRING RoutineName2;
  RtlInitAnsiString(&RoutineName2, (PSTR)"_snwprintf");

  UNICODE_STRING NtdllPath2;
  RtlInitUnicodeString(&NtdllPath2, (PWSTR)L"ntdll.dll");

  HANDLE NtdllHandle2;
  LdrGetDllHandle(NULL, 0, &NtdllPath2, &NtdllHandle2);
  LdrGetProcedureAddress(NtdllHandle2, &RoutineName2, 0, (PVOID*)&my_snwprintf);

  //
  // Make us unloadable (by FreeLibrary calls).
  //

  LdrAddRefDll(LDR_ADDREF_DLL_PIN, ModuleHandle);

  //
  // Hide this DLL from the PEB.
  //

  PPEB Peb = NtCurrentPeb();
  PLIST_ENTRY ListEntry;

  for (ListEntry =   Peb->Ldr->InLoadOrderModuleList.Flink;
       ListEntry != &Peb->Ldr->InLoadOrderModuleList;
       ListEntry =   ListEntry->Flink)
  {
    PLDR_DATA_TABLE_ENTRY LdrEntry = CONTAINING_RECORD(ListEntry, LDR_DATA_TABLE_ENTRY, InLoadOrderLinks);

    //
    // ModuleHandle is same as DLL base address.
    //

    if (LdrEntry->DllBase == ModuleHandle)
    {
      RemoveEntryList(&LdrEntry->InLoadOrderLinks);
      RemoveEntryList(&LdrEntry->InInitializationOrderLinks);
      RemoveEntryList(&LdrEntry->InMemoryOrderLinks);
      RemoveEntryList(&LdrEntry->HashLinks);

      break;
    }
  }

  //
  // Create exports for Wow64Log* functions in
  // the PE header of this DLL.
  //

  Wow64LogCreateExports(ModuleHandle);


  //
  // Register ETW provider.
  //

  EtwEventRegister(&ProviderGuid,
                   NULL,
                   NULL,
                   &ProviderHandle);

  //
  // Create dummy thread - used for testing.
  //

  // RtlCreateUserThread(NtCurrentProcess(),
  //                     NULL,
  //                     FALSE,
  //                     0,
  //                     0,
  //                     0,
  //                     &ThreadRoutine,
  //                     NULL,
  //                     NULL,
  //                     NULL);

  //
  // Get command line of the current process and send it.
  //

  PWSTR CommandLine = Peb->ProcessParameters->CommandLine.Buffer;
  PWSTR CommandLine2 = Peb->ProcessParameters->ImagePathName.Buffer;

  UNICODE_STRING temp;
  UNICODE_STRING temp2;
  RtlInitUnicodeString(&temp, (PWSTR)CommandLine2);
  RtlInitUnicodeString(&temp2, (PWSTR)L"C:\\Windows\\system32\\consent.exe");
  if (RtlEqualUnicodeString(&temp, &temp2, true))
  {
    G_sys_proc = true;
  }


  WCHAR Buffer2[128];
  my_snwprintf(Buffer2,
    RTL_NUMBER_OF(Buffer2),
    L"%s",
    CommandLine2);
  json_log("ImagePathName", Buffer2);

  WCHAR Buffer[128];
  my_snwprintf(Buffer,
             RTL_NUMBER_OF(Buffer),
             L"Arch: %s, CommandLine: %s",
             ARCH_W,
             CommandLine);

  json_log("LAUNCH", Buffer);
  //EtwEventWriteString(ProviderHandle, 0, 0, Buffer);

  //
  // Hook all functions.
  //

  return EnableDetours();
}

NTSTATUS
NTAPI
OnProcessDetach(
  _In_ HANDLE ModuleHandle
  )
{
  //
  // Unhook all functions.
  //

  return DisableDetours();
}

EXTERN_C
BOOL
NTAPI
NtDllMain(
  _In_ HANDLE ModuleHandle,
  _In_ ULONG Reason,
  _In_ LPVOID Reserved
  )
{
  switch (Reason)
  {
    case DLL_PROCESS_ATTACH:
      OnProcessAttach(ModuleHandle);
      break;

    case DLL_PROCESS_DETACH:
      OnProcessDetach(ModuleHandle);
      break;

    case DLL_THREAD_ATTACH:

      break;

    case DLL_THREAD_DETACH:

      break;
  }

  return TRUE;
}

