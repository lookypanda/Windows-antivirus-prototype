#define _ARM_WINAPI_PARTITION_DESKTOP_SDK_AVAILABLE 1

#include <stdio.h>

#include <windows.h>
#include <evntrace.h>
#include <evntcons.h>
#include <nlohmann/json.hpp>
#include "install.h"

HANDLE hNamedPipe; //global pipe
#define PIPE_NAME  "\\\\.\\pipe\\mynamedpipe"
//
// GUID:
//   {a4b4ba50-a667-43f5-919b-1e52a6d69bd5}
//

GUID ProviderGuid = {
  0xa4b4ba50, 0xa667, 0x43f5, { 0x91, 0x9b, 0x1e, 0x52, 0xa6, 0xd6, 0x9b, 0xd5 }
};

//
// GUID:
//   {53d82d11-cede-4dff-8eb4-f06631800128}
//

GUID SessionGuid = {
  0x53d82d11, 0xcede, 0x4dff, { 0x8e, 0xb4, 0xf0, 0x66, 0x31, 0x80, 0x1, 0x28 }
};

TCHAR SessionName[] = TEXT("InjSession");
FILE* log_file;
VOID
WINAPI
TraceEventCallback(
  _In_ PEVENT_RECORD EventRecord
)
{
  if (!EventRecord->UserData)
  {
    return;
  }

  //
  // TODO: Check that EventRecord contains only WCHAR string.
  //
  using json = nlohmann::json;
  json jevent;
  jevent["PID"] = EventRecord->EventHeader.ProcessId;
  jevent["TID"] = EventRecord->EventHeader.ThreadId;
  SYSTEMTIME st;
  GetSystemTime(&st);
  std::string time = std::to_string(st.wSecond) + ":" + std::to_string(st.wMinute) + ":" + std::to_string(st.wHour) + " "
    + std::to_string(st.wDay) + "."
    + std::to_string(st.wMonth) + "."
    + std::to_string(st.wYear);
  jevent["TIME"] = time;
  //printf("TEST  %s \n", jevent.dump().c_str());

  jevent["FUNCT"] = "";
  jevent["PARAM"] = "";


  wprintf(L"[PID:%04d][TID:%04d] %s\n",
    EventRecord->EventHeader.ProcessId,
    EventRecord->EventHeader.ThreadId,
    (PWCHAR)EventRecord->UserData);
  fwprintf(log_file, L"[PID:%04d][TID:%04d] %s\n",
    EventRecord->EventHeader.ProcessId,
    EventRecord->EventHeader.ThreadId,
    (PWCHAR)EventRecord->UserData);
  fflush(log_file);

  std::wstring wstr((PWCHAR)EventRecord->UserData);
  bool isParseOk;
  try
  {
    std::replace(wstr.begin(), wstr.end(), L'\\', L'/');


    auto res = wstr.find(L"CommandLine: \"");
    if (res != -1) {
      //wprintf(L"FIND");
      //wprintf(L"%d \n", res);
      size_t  posn;
      std::wstring replaceFrom = L"CommandLine: \"";
      std::wstring replaceTo = L"CommandLine: ";
      while (std::wstring::npos != (posn = wstr.find(replaceFrom)))
      {
        wstr.replace(posn, replaceFrom.length(), replaceTo);
      }

      size_t  posn2;
      std::wstring replaceFrom2 = L"\" /c";
      std::wstring replaceTo2 = L" /c";
      while (std::wstring::npos != (posn2 = wstr.find(replaceFrom2)))
      {
        wstr.replace(posn2, replaceFrom2.length(), replaceTo2);
      }

      size_t  posn3;
      std::wstring replaceFrom3 = L".exe\" \"";
      std::wstring replaceTo3 = L".exe\"";
      while (std::wstring::npos != (posn3 = wstr.find(replaceFrom3)))
      {
        wstr.replace(posn3, replaceFrom3.length(), replaceTo3);
      }
      //wprintf(L"\n");
      //wprintf(wstr.c_str());
      //wprintf(L"\n");
    }

    json f2 = json::parse(wstr);
    isParseOk = true;
    jevent["FUNCT"] = f2["FUNCT"].get<std::string>();
    jevent["PARAM"] = f2["PARAM"].get<std::string>();

  }
  catch (const nlohmann::detail::parse_error ex)
  {
    isParseOk = false;
    printf("parse_error\n");
  }
  catch (const nlohmann::detail::out_of_range ex2)
  {
    isParseOk = false;
    printf("out_of_range\n");
  }
  try
  {
    //writing to pipe

    DWORD  cbWritten;
    WriteFile(hNamedPipe, jevent.dump().c_str(), strlen(jevent.dump().c_str()) + 1,
      &cbWritten, NULL);
    printf("PIPEok\n");
    //CloseHandle(hNamedPipe);

    //DWORD  cbRead;
    //char   answer[512];
    //ReadFile(hNamedPipe, answer, 512, &cbRead, NULL);
    //printf("PIPE server answer:  %s", answer);
  }
  catch (...) {
    printf("PIPE ERRRR\n");
  }
}

ULONG
NTAPI
TraceStart(
  VOID
  )
{
  try
  {
  //pipe connection
  hNamedPipe = CreateFileA(
   PIPE_NAME, GENERIC_WRITE,
    0, NULL, OPEN_EXISTING, 0, NULL);
  }
  catch (...) {
    printf("PIPE ERRRR\n");
  }
  //
  // Start new trace session.
  // For an awesome blogpost on ETW API, see:
  // https://caseymuratori.com/blog_0025
  //
  
  ULONG ErrorCode;

  TRACEHANDLE TraceSessionHandle = INVALID_PROCESSTRACE_HANDLE;

  BYTE Buffer[sizeof(EVENT_TRACE_PROPERTIES) + 4096];
  RtlZeroMemory(Buffer, sizeof(Buffer));

  PEVENT_TRACE_PROPERTIES EventTraceProperties = (PEVENT_TRACE_PROPERTIES)Buffer;
  EventTraceProperties->Wnode.BufferSize = sizeof(Buffer);
  EventTraceProperties->Wnode.ClientContext = 1; // Use QueryPerformanceCounter, see MSDN
  EventTraceProperties->Wnode.Flags = WNODE_FLAG_TRACED_GUID;
  EventTraceProperties->LogFileMode = PROCESS_TRACE_MODE_REAL_TIME;
  EventTraceProperties->LoggerNameOffset = sizeof(EVENT_TRACE_PROPERTIES);

  ErrorCode = StartTrace(&TraceSessionHandle, SessionName, EventTraceProperties);
  if (ErrorCode != ERROR_SUCCESS)
  {
    return 1;
  }

  //
  // Enable tracing of our provider.
  //

  ErrorCode = EnableTrace(TRUE, 0, 0, &ProviderGuid, TraceSessionHandle);
  if (ErrorCode != ERROR_SUCCESS)
  {
    return 1;
  }

  EVENT_TRACE_LOGFILE TraceLogfile = { 0 };
  TraceLogfile.LoggerName = SessionName;
  TraceLogfile.ProcessTraceMode = PROCESS_TRACE_MODE_EVENT_RECORD | PROCESS_TRACE_MODE_REAL_TIME;
  TraceLogfile.EventRecordCallback = &TraceEventCallback;

  //
  // Open real-time tracing session.
  //

  TRACEHANDLE TraceHandle = OpenTrace(&TraceLogfile);
  if (TraceHandle == INVALID_PROCESSTRACE_HANDLE)
  {
    //
    // Synthetic error code.
    //
    ErrorCode = ERROR_FUNCTION_FAILED;
    goto Exit;
  }

  //
  // Process trace events.  This call is blocking.
  //

  ErrorCode = ProcessTrace(&TraceHandle, 1, NULL, NULL);

Exit:
  if (TraceHandle)
  {
    CloseTrace(TraceHandle);
  }


  if (TraceSessionHandle)
  {
    CloseTrace(TraceSessionHandle);
  }

  RtlZeroMemory(Buffer, sizeof(Buffer));
  EventTraceProperties->Wnode.BufferSize = sizeof(Buffer);
  StopTrace(0, SessionName, EventTraceProperties);

  if (ErrorCode != ERROR_SUCCESS)
  {
    printf("Error: %08x\n", ErrorCode);
  }

  return ErrorCode;
}

VOID
NTAPI
TraceStop(
  VOID
  )
{

  BYTE Buffer[sizeof(EVENT_TRACE_PROPERTIES) + 4096];
  RtlZeroMemory(Buffer, sizeof(Buffer));

  PEVENT_TRACE_PROPERTIES EventTraceProperties = (PEVENT_TRACE_PROPERTIES)Buffer;
  EventTraceProperties->Wnode.BufferSize = sizeof(Buffer);

  StopTrace(0, SessionName, EventTraceProperties);
  
}

//////////////////////////////////////////////////////////////////////////

BOOLEAN
DoInstallUninstall(
  _In_ BOOLEAN Install
  )
{
  TCHAR driverLocation[MAX_PATH] = { 0 };

  //
  // The driver is not started yet so let us install the driver.
  // First setup full path to driver name.
  //

  if (!SetupDriverName(driverLocation, sizeof(driverLocation)))
  {
    return FALSE;
  }

  if (Install)
  {
    if (!ManageDriver(TEXT(DRIVER_NAME),
                      driverLocation,
                      DRIVER_FUNC_INSTALL))
    {
      printf("Unable to install driver.\n");

      //
      // Error - remove driver.
      //

      ManageDriver(TEXT(DRIVER_NAME),
                   driverLocation,
                   DRIVER_FUNC_REMOVE);

      return FALSE;
    }
  }
  else
  {
    //
    // Ignore errors.
    //

    ManageDriver(TEXT(DRIVER_NAME),
                 driverLocation,
                 DRIVER_FUNC_REMOVE);
  }

  return TRUE;
}

BOOL
WINAPI
CtrlCHandlerRoutine(
  _In_ DWORD dwCtrlType
  )
{
  if (dwCtrlType == CTRL_C_EVENT)
  {
    //
    // Ctrl+C was pressed, stop the trace session.
    //
    printf("Ctrl+C pressed, stopping trace session...\n");

    TraceStop();
    fclose(log_file);
  }

  return FALSE;
}

int main(int argc, char* argv[])
{
//   LoadLibrary(TEXT("injdllx64.dll"));
//
//   return 0;
//
  SetConsoleCtrlHandler(&CtrlCHandlerRoutine, TRUE);

  //
  // Stop any previous trace session (if exists).
  //

  TraceStop();

  //
  // Parse command-line parameters.
  //

  if (argc == 2)
  {
    TCHAR DriverLocation[MAX_PATH];
    SetupDriverName(DriverLocation, sizeof(DriverLocation));

    if (!strcmp(argv[1], "-i"))
    {
      printf("Installing driver...\n");

      if (DoInstallUninstall(TRUE))
      {
        printf("Driver installed!\n");
      }
      else
      {
        printf("Error!\n");
        return EXIT_FAILURE;
      }
    }
    else if (!strcmp(argv[1], "-u"))
    {
      printf("Uninstalling driver...\n");

      DoInstallUninstall(FALSE);

      return EXIT_SUCCESS;
    }
  }
  auto err= _wfopen_s(&log_file,L"log.txt", L"w");
  printf("Starting tracing session...\n");
  

  ULONG ErrorCode = TraceStart();

  return ErrorCode == ERROR_SUCCESS
    ? EXIT_SUCCESS
    : EXIT_FAILURE;
}
